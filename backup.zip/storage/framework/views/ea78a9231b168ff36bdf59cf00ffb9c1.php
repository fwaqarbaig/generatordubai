<?php $__env->startSection('seo_meta'); ?>
    <!-- Primary Meta Tags -->
    <title><?php echo e($post->seo_title); ?> - <?php echo e(config('app.name', 'Generator Dubai')); ?></title>
    <meta name="title" content="<?php echo e($post->seo_title); ?> - <?php echo e(config('app.name', 'Generator Dubai')); ?>">
    <meta name="description" content="<?php echo e($post->seo_description); ?>">
    <?php if($post->meta_keywords): ?>
        <meta name="keywords" content="<?php echo e($post->meta_keywords); ?>">
    <?php endif; ?>
    <link rel="canonical" href="<?php echo e($post->canonical_url ?: url()->current()); ?>">
    <meta name="robots" content="<?php echo e($post->is_indexable ? 'index, follow' : 'noindex, nofollow'); ?>">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="article">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta property="og:title" content="<?php echo e($post->og_title ?: $post->seo_title); ?>">
    <meta property="og:description" content="<?php echo e($post->og_description ?: $post->seo_description); ?>">
    <?php if($post->seo_image): ?>
        <meta property="og:image" content="<?php echo e($post->seo_image); ?>">
    <?php endif; ?>
    <meta property="og:site_name" content="<?php echo e(config('app.name', 'Generator Dubai')); ?>">
    <?php if($post->published_at): ?>
        <meta property="article:published_time" content="<?php echo e($post->published_at->toIso8601String()); ?>">
    <?php endif; ?>

    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:url" content="<?php echo e(url()->current()); ?>">
    <meta name="twitter:title" content="<?php echo e($post->og_title ?: $post->seo_title); ?>">
    <meta name="twitter:description" content="<?php echo e($post->og_description ?: $post->seo_description); ?>">
    <?php if($post->seo_image): ?>
        <meta name="twitter:image" content="<?php echo e($post->seo_image); ?>">
    <?php endif; ?>

    <!-- Schema.org BlogPosting JSON-LD -->
    <script type="application/ld+json">
    <?php echo json_encode([
      '@context' => 'https://schema.org',
      '@type' => 'BlogPosting',
      'mainEntityOfPage' => [
        '@type' => 'WebPage',
        '@id' => route('post.show', $post->slug),
      ],
      'headline' => $post->title,
      'description' => $post->seo_description,
      'image' => $post->featured_image_url ? [$post->featured_image_url] : [url('/storage/media/2026/09/1-y7ja6x.webp')],
      'datePublished' => $post->published_at ? $post->published_at->toIso8601String() : $post->created_at->toIso8601String(),
      'dateModified' => $post->updated_at->toIso8601String(),
      'author' => [
        '@type' => 'Organization',
        'name' => 'Generator Dubai Engineering Team',
        'url' => 'https://generatordubai.com',
      ],
      'publisher' => [
        '@type' => 'LocalBusiness',
        'name' => 'Generator Dubai',
        'url' => 'https://generatordubai.com',
        'telephone' => '+971569213754',
        'address' => [
          '@type' => 'PostalAddress',
          'streetAddress' => 'Suit 44, King Faisal Street',
          'addressLocality' => 'Sharjah',
          'addressCountry' => 'AE',
        ],
      ],
    ], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT); ?>

    </script>

    <!-- Schema.org BreadcrumbList JSON-LD -->
    <script type="application/ld+json">
    <?php echo json_encode([
      '@context' => 'https://schema.org',
      '@type' => 'BreadcrumbList',
      'itemListElement' => [
        [
          '@type' => 'ListItem',
          'position' => 1,
          'name' => 'Home',
          'item' => route('home'),
        ],
        [
          '@type' => 'ListItem',
          'position' => 2,
          'name' => 'Articles',
          'item' => route('blog.index'),
        ],
        [
          '@type' => 'ListItem',
          'position' => 3,
          'name' => $post->title,
          'item' => route('post.show', $post->slug),
        ],
      ],
    ], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT); ?>

    </script>

    <!-- Custom Schema.org JSON-LD (from Dashboard) -->
    <?php if (isset($component)) { $__componentOriginal97aaa7ec6ba4597a3ca98c8c57a79ecd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal97aaa7ec6ba4597a3ca98c8c57a79ecd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.schema-json-ld','data' => ['schema' => $post->schema_markup]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('schema-json-ld'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['schema' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($post->schema_markup)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal97aaa7ec6ba4597a3ca98c8c57a79ecd)): ?>
<?php $attributes = $__attributesOriginal97aaa7ec6ba4597a3ca98c8c57a79ecd; ?>
<?php unset($__attributesOriginal97aaa7ec6ba4597a3ca98c8c57a79ecd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal97aaa7ec6ba4597a3ca98c8c57a79ecd)): ?>
<?php $component = $__componentOriginal97aaa7ec6ba4597a3ca98c8c57a79ecd; ?>
<?php unset($__componentOriginal97aaa7ec6ba4597a3ca98c8c57a79ecd); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="py-12 bg-slate-50 min-h-screen">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Breadcrumbs -->
        <nav class="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-8 flex-wrap" aria-label="Breadcrumb">
            <a href="<?php echo e(route('home')); ?>" class="hover:text-brand-600 transition">Home</a>
            <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-400"></i>
            <a href="<?php echo e(route('blog.index')); ?>" class="hover:text-brand-600 transition">Articles</a>
            <?php if($post->categories->first()): ?>
                <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-slate-400"></i>
                <a href="<?php echo e(route('category.show', $post->categories->first()->slug)); ?>" class="text-brand-600 hover:underline">
                    <?php echo e($post->categories->first()->name); ?>

                </a>
            <?php endif; ?>
        </nav>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
            
            <!-- Left Main Column: Article Content & Metadata (8 cols) -->
            <div class="lg:col-span-8 space-y-10">
                <article class="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200/90 shadow-sm space-y-8">
                    <!-- Article Categories & Badges -->
                    <header class="space-y-6">
                        <div class="flex items-center gap-2 flex-wrap">
                            <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('category.show', $c->slug)); ?>" class="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-brand-50 text-brand-700 hover:bg-brand-100 transition">
                                    <?php echo e($c->name); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <h1 class="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-black text-slate-900 tracking-tight leading-tight">
                            <?php echo e($post->title); ?>

                        </h1>

                        <?php if($post->excerpt): ?>
                            <p class="text-base sm:text-lg text-slate-600 leading-relaxed font-normal">
                                <?php echo e($post->excerpt); ?>

                            </p>
                        <?php endif; ?>

                        <!-- Publication Metadata Row -->
                        <div class="pt-6 border-t border-slate-100 flex items-center justify-between flex-wrap gap-4">
                            <div class="flex items-center gap-2.5 text-xs text-slate-500 font-medium">
                                <span class="inline-flex items-center gap-1.5">
                                    <i data-lucide="calendar" class="w-4 h-4 text-slate-400"></i>
                                    <?php echo e($post->published_at ? $post->published_at->format('F d, Y') : $post->created_at->format('F d, Y')); ?>

                                </span>
                                <span>•</span>
                                <span class="inline-flex items-center gap-1.5">
                                    <i data-lucide="clock" class="w-4 h-4 text-slate-400"></i>
                                    <?php echo e($post->reading_time); ?> min read
                                </span>
                            </div>

                            <?php if(auth()->guard()->check()): ?>
                                <?php if(auth()->user()->canManageContent()): ?>
                                    <a href="<?php echo e(route('admin.posts.edit', $post)); ?>" class="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-bold text-slate-800 transition">
                                        <i data-lucide="edit-3" class="w-3.5 h-3.5"></i> Edit Post
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </header>

                    <!-- Featured Image -->
                    <?php if($post->featured_image_url): ?>
                        <div class="rounded-2xl overflow-hidden aspect-[21/9] sm:aspect-[16/8] shadow-md bg-slate-100">
                            <img src="<?php echo e($post->featured_image_url); ?>" 
                                 alt="<?php echo e($post->title); ?>" 
                                 width="1200" 
                                 height="600" 
                                 loading="eager" 
                                 fetchpriority="high" 
                                 class="w-full h-full object-cover">
                        </div>

                    <?php endif; ?>

                    <!-- Article WYSIWYG Content Body -->
                    <div class="prose prose-slate prose-lg max-w-none py-4 leading-relaxed">
                        <?php echo $post->content; ?>

                    </div>

                    <!-- Tags List -->
                    <?php if($post->tags->count()): ?>
                        <div class="pt-8 border-t border-slate-200 space-y-3">
                            <span class="text-xs font-bold uppercase tracking-wider text-slate-400">Tagged with</span>
                            <div class="flex flex-wrap gap-2">
                                <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('tag.show', $t->slug)); ?>" class="px-3 py-1 rounded-xl bg-slate-100 text-xs font-medium text-slate-700 hover:bg-brand-50 hover:text-brand-600 transition">
                                        #<?php echo e($t->name); ?>

                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </article>

                <!-- High-Impact Commercial Power Callout (Contextual Internal Link) -->
                <?php if(isset($targetedService) && $targetedService): ?>
                    <div class="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950 text-white shadow-xl border border-amber-500/30 space-y-5">
                        <div class="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
                            <div class="flex items-center gap-2">
                                <span class="inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30">
                                    <span class="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse mr-1.5"></span> RAPID POWER DISPATCH
                                </span>
                                <span class="text-xs text-slate-300 font-medium">20 kVA &ndash; 2500 kVA Fleet &bull; All 7 Emirates</span>
                            </div>
                            <span class="text-xs font-bold text-amber-400">24/7 Emergency Mobilization</span>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                            <div class="md:col-span-8 space-y-2">
                                <h3 class="text-lg sm:text-xl font-bold font-display text-white">
                                    Planning a Power Installation or Facing an Outage? Deploy <span class="text-amber-400"><?php echo e($targetedService->title); ?></span>
                                </h3>
                                <p class="text-xs sm:text-sm text-slate-300 leading-relaxed">
                                    Our turnkey power solutions include synchronized multi-megawatt configurations, acoustic soundproofing, automatic transfer switches, and certified electrical engineer dispatch across Dubai & the UAE.
                                </p>
                            </div>

                            <div class="md:col-span-4 flex flex-col sm:flex-row md:flex-col gap-2.5">
                                <a href="<?php echo e(route('service.show', $targetedService->slug)); ?>" class="w-full py-3 px-4 rounded-xl font-bold text-xs bg-amber-500 hover:bg-amber-400 text-slate-950 text-center shadow-lg shadow-amber-500/20 transition flex items-center justify-center gap-2">
                                    <span>Explore <?php echo e($targetedService->title); ?></span>
                                    <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
                                </a>
                                <a href="tel:+971569213754" class="w-full py-2.5 px-4 rounded-xl font-bold text-xs bg-emerald-600 hover:bg-emerald-500 text-white text-center transition flex items-center justify-center gap-2">
                                    <i data-lucide="phone-call" class="w-3.5 h-3.5"></i>
                                    <span>Call 24/7: +971 56 921 3754</span>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Prev / Next Navigation -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <?php if($previousPost): ?>
                        <a href="<?php echo e(route('post.show', $previousPost->slug)); ?>" class="p-4 rounded-2xl bg-white border border-slate-200 hover:border-brand-500 transition group space-y-1 block shadow-xs">
                            <span class="text-slate-400 flex items-center gap-1"><i data-lucide="arrow-left" class="w-3.5 h-3.5"></i> Previous Article</span>
                            <span class="font-bold text-slate-900 group-hover:text-brand-600 transition line-clamp-1 block"><?php echo e($previousPost->title); ?></span>
                        </a>
                    <?php else: ?>
                        <div></div>
                    <?php endif; ?>

                    <?php if($nextPost): ?>
                        <a href="<?php echo e(route('post.show', $nextPost->slug)); ?>" class="p-4 rounded-2xl bg-white border border-slate-200 hover:border-brand-500 transition group space-y-1 block sm:text-right shadow-xs">
                            <span class="text-slate-400 flex items-center justify-end gap-1">Next Article <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i></span>
                            <span class="font-bold text-slate-900 group-hover:text-brand-600 transition line-clamp-1 block"><?php echo e($nextPost->title); ?></span>
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Related Posts Section -->
                <?php if($relatedPosts->count()): ?>
                    <div class="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
                        <div class="flex items-center justify-between border-b border-slate-100 pb-4">
                            <div>
                                <h3 class="text-lg sm:text-xl font-bold text-slate-900">Related Articles</h3>
                                <p class="text-xs text-slate-500 mt-0.5">Explore more technical power guides, sizing manuals, and UAE field engineering studies</p>
                            </div>
                            <a href="<?php echo e(route('blog.index')); ?>" class="text-xs font-bold text-brand-600 hover:text-brand-700 hidden sm:inline-flex items-center gap-1">
                                <span>All Articles</span>
                                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
                            </a>
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-5">
                            <?php $__currentLoopData = $relatedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <article class="bg-slate-50 rounded-2xl border border-slate-100 overflow-hidden shadow-xs hover:shadow-md transition group flex flex-col justify-between">
                                    <a href="<?php echo e(route('post.show', $rPost->slug)); ?>" class="aspect-video block overflow-hidden bg-slate-200">
                                        <?php if($rPost->featured_image_url): ?>
                                             <img src="<?php echo e($rPost->featured_image_url); ?>" 
                                                  alt="<?php echo e($rPost->title); ?>" 
                                                  width="400" 
                                                  height="225" 
                                                  loading="lazy" 
                                                  class="w-full h-full object-cover group-hover:scale-105 transition">
                                        <?php else: ?>

                                            <div class="w-full h-full flex items-center justify-center text-slate-300">
                                                <i data-lucide="image" class="w-8 h-8"></i>
                                            </div>
                                        <?php endif; ?>
                                    </a>
                                    <div class="p-4 space-y-2 flex-1 flex flex-col justify-between">
                                        <h4 class="text-xs font-bold text-slate-900 group-hover:text-brand-600 transition line-clamp-2">
                                            <a href="<?php echo e(route('post.show', $rPost->slug)); ?>"><?php echo e($rPost->title); ?></a>
                                        </h4>
                                        <span class="text-[10px] text-slate-400"><?php echo e($rPost->published_at ? $rPost->published_at->format('M d, Y') : ''); ?></span>
                                    </div>
                                </article>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Right Sticky Column: Form & Other Services (4 cols) -->
            <aside class="lg:col-span-4 lg:sticky lg:top-24">
                <?php echo $__env->make('frontend.partials.service-sidebar', [
                    'post' => $post,
                    'services' => $services ?? null,
                    'subject' => 'Power Solution Inquiry from Article: ' . $post->title,
                    'whatsappMessage' => 'Hello Generator Dubai, I am reading "' . $post->title . '" and would like to request generator rental & engineering support.'
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </aside>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\CMS\saudia_site\resources\views/frontend/blog/show.blade.php ENDPATH**/ ?>