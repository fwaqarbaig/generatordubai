<?php
    $isEdit = isset($service);
    $actionUrl = $isEdit ? route('admin.services.update', $service) : route('admin.services.store');
    $currentBenchmarks = $benchmarks ?? ($service->effective_benchmarks ?? [
        'standard' => 'ISO 8528-1:2018 / DEWA & ADDC Certified',
        'evaluation' => '100% Free Power Sizing & Technical Site Audit',
        'guarantee' => '99.98% Electrical Power Uptime SLA Guarantee',
        'turnaround' => '2-Hour Emergency Mobilization Across All 7 Emirates',
        'courier' => 'Turnkey Heavy Crane Offloading, Cable Termination & Commissioning',
    ]);
?>

<form action="<?php echo e($actionUrl); ?>" method="POST" id="serviceForm" class="space-y-8">
    <?php echo csrf_field(); ?>
    <?php if($isEdit): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Main Left Column (2 Cols) -->
        <div class="lg:col-span-2 space-y-6">

            <!-- Title & Permalink & Hero Badge Card -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
                <div>
                    <label for="serviceTitle" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Service Title</label>
                    <input type="text" id="serviceTitle" name="title" required value="<?php echo e(old('title', $service->title ?? '')); ?>" 
                           placeholder="e.g. Turnkey Diesel Generator Rental"
                           class="w-full px-4 py-3 text-lg font-bold rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-600 transition">
                </div>

                <!-- Slug / Permalink Box -->
                <div class="flex items-center gap-2 text-xs text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-200/60" x-data="{ editingSlug: false }">
                    <span class="font-semibold text-slate-600">Permalink:</span>
                    <span class="text-slate-400"><?php echo e(url('/service')); ?>/</span>
                    <span x-show="!editingSlug" id="slugDisplay" class="font-mono text-brand-600 font-bold"><?php echo e(old('slug', $service->slug ?? 'your-service-slug')); ?></span>
                    <input type="text" id="serviceSlug" name="slug" value="<?php echo e(old('slug', $service->slug ?? '')); ?>" x-show="editingSlug"
                           class="px-2 py-0.5 rounded border border-slate-300 font-mono text-xs focus:outline-none focus:border-brand-600 w-64">
                    <button type="button" @click="editingSlug = !editingSlug" class="ml-auto text-xs text-brand-600 font-semibold hover:underline">
                        <span x-text="editingSlug ? 'Done' : 'Edit'"></span>
                    </button>
                </div>

                <!-- Hero Lab Badge -->
                <div>
                    <div class="flex items-center justify-between mb-1.5">
                        <label for="serviceHeroBadge" class="block text-xs font-bold uppercase tracking-wider text-slate-700">Hero Certification Badge</label>
                        <span class="text-[11px] text-slate-400">Pill badge shown in the service header</span>
                    </div>
                    <input type="text" id="serviceHeroBadge" name="hero_badge" value="<?php echo e(old('hero_badge', $service->hero_badge ?? '20 kVA to 2500 kVA • 52°C Desert Tropicalized Fleet')); ?>" 
                           placeholder="e.g. 20 kVA to 2500 kVA • 52°C Desert Tropicalized Fleet"
                           class="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-600">
                    <div class="flex flex-wrap gap-1.5 mt-2">
                        <button type="button" onclick="document.getElementById('serviceHeroBadge').value = '20 kVA to 2500 kVA • 52°C Desert Tropicalized Fleet'" class="text-[10px] px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded">20-2500 kVA Fleet</button>
                        <button type="button" onclick="document.getElementById('serviceHeroBadge').value = '1 MW to 50 MW Modular Synchronized Power Plants'" class="text-[10px] px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded">Multi-MW Plants</button>
                        <button type="button" onclick="document.getElementById('serviceHeroBadge').value = 'Civil Defense Compliant Generator AMC • 24/7 SLA'" class="text-[10px] px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded">Certified AMC</button>
                        <button type="button" onclick="document.getElementById('serviceHeroBadge').value = 'Used & Scrap Portacabin Trading • Instant Cash Buyer'" class="text-[10px] px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded">Portacabin Trading</button>
                    </div>
                </div>

                <!-- Tagline -->
                <div>
                    <label for="serviceTagline" class="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">Tagline / Subheadline</label>
                    <input type="text" id="serviceTagline" name="tagline" value="<?php echo e(old('tagline', $service->tagline ?? '')); ?>" 
                           placeholder="e.g. Generator Rental in UAE | 20 kVA to 2500 kVA Prime & Standby Silent Power"
                           class="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-600">
                </div>
            </div>

            <!-- Commercial Power Standards & SLA Benchmarks Card -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
                <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div>
                        <h3 class="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-2">
                            <i data-lucide="shield-check" class="w-4 h-4 text-emerald-600"></i>
                            <span>Commercial Power Standards & SLA Benchmarks</span>
                        </h3>
                        <p class="text-[11px] text-slate-400 mt-0.5">Displayed in the verified engineering metrics box on the frontend</p>
                    </div>
                    <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">Live on Service Hero</span>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[11px] font-bold text-slate-600 mb-1">Engineering Standard</label>
                        <input type="text" name="benchmark_standard" value="<?php echo e(old('benchmark_standard', $currentBenchmarks['standard'] ?? 'ISO 8528-1:2018 / DEWA & ADDC Certified')); ?>"
                               class="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500/20">
                    </div>

                    <div>
                        <label class="block text-[11px] font-bold text-slate-600 mb-1">Site Sizing Policy</label>
                        <input type="text" name="benchmark_evaluation" value="<?php echo e(old('benchmark_evaluation', $currentBenchmarks['evaluation'] ?? '100% Free Power Sizing & Technical Site Audit')); ?>"
                               class="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500/20">
                    </div>

                    <div>
                        <label class="block text-[11px] font-bold text-slate-600 mb-1">Uptime SLA Guarantee</label>
                        <input type="text" name="benchmark_guarantee" value="<?php echo e(old('benchmark_guarantee', $currentBenchmarks['guarantee'] ?? '99.98% Electrical Power Uptime SLA Guarantee')); ?>"
                               class="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500/20">
                    </div>

                    <div>
                        <label class="block text-[11px] font-bold text-slate-600 mb-1">Emergency Dispatch SLA</label>
                        <input type="text" name="benchmark_turnaround" value="<?php echo e(old('benchmark_turnaround', $currentBenchmarks['turnaround'] ?? '2-Hour Emergency Mobilization Across All 7 Emirates')); ?>"
                                class="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500/20">
                    </div>

                    <div class="md:col-span-2">
                        <label class="block text-[11px] font-bold text-slate-600 mb-1">UAE Offloading & Commissioning</label>
                        <input type="text" name="benchmark_courier" value="<?php echo e(old('benchmark_courier', $currentBenchmarks['courier'] ?? 'Turnkey Heavy Crane Offloading, Cable Termination & Commissioning')); ?>"
                               class="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500/20">
                    </div>
                </div>
            </div>

            <!-- Ultimate Content Editor (Dual-Mode: Visual / HTML Source / Live Preview) -->
            <div class="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden" 
                 x-data="serviceContentEditor({ initial: <?php echo \Illuminate\Support\Js::from(old('content', $service->content ?? ''))->toHtml() ?> })">
                
                <!-- Editor Header Toolbar & Tabs -->
                <div class="p-4 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3 border-b border-slate-800">
                    <div class="flex items-center gap-3">
                        <span class="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                            <i data-lucide="file-text" class="w-4 h-4 text-brand-400"></i>
                            <span>Detailed Service Content</span>
                        </span>
                        
                        <!-- Mode Selector Tabs -->
                        <div class="flex items-center bg-slate-800 p-1 rounded-xl text-xs font-semibold">
                            <button type="button" @click="setTab('code')" 
                                    :class="activeTab === 'code' ? 'bg-brand-600 text-white shadow-sm' : 'text-slate-300 hover:text-white'"
                                    class="px-3 py-1.5 rounded-lg transition flex items-center gap-1.5">
                                <i data-lucide="code" class="w-3.5 h-3.5"></i>
                                <span>HTML Source Code</span>
                            </button>
                            <button type="button" @click="setTab('visual')" 
                                    :class="activeTab === 'visual' ? 'bg-brand-600 text-white shadow-sm' : 'text-slate-300 hover:text-white'"
                                    class="px-3 py-1.5 rounded-lg transition flex items-center gap-1.5">
                                <i data-lucide="eye" class="w-3.5 h-3.5"></i>
                                <span>Visual WYSIWYG</span>
                            </button>
                            <button type="button" @click="setTab('preview')" 
                                    :class="activeTab === 'preview' ? 'bg-brand-600 text-white shadow-sm' : 'text-slate-300 hover:text-white'"
                                    class="px-3 py-1.5 rounded-lg transition flex items-center gap-1.5">
                                <i data-lucide="monitor" class="w-3.5 h-3.5"></i>
                                <span>Live Preview</span>
                            </button>
                        </div>
                    </div>

                    <!-- Quick Snippet Inserters -->
                    <div class="flex items-center gap-2">
                        <div class="relative" x-data="{ openSnippets: false }">
                            <button type="button" @click="openSnippets = !openSnippets" 
                                    class="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition">
                                <i data-lucide="plus-circle" class="w-3.5 h-3.5 text-brand-400"></i>
                                <span>Insert Section</span>
                                <i data-lucide="chevron-down" class="w-3 h-3 text-slate-400"></i>
                            </button>
                            <div x-show="openSnippets" x-cloak @click.outside="openSnippets = false" 
                                 class="absolute right-0 mt-1 w-56 rounded-xl bg-slate-800 text-slate-200 border border-slate-700 shadow-xl py-1 text-xs z-30">
                                <button type="button" @click="insertSnippet('faq'); openSnippets = false" class="w-full text-left px-3 py-2 hover:bg-slate-700 flex items-center gap-2">
                                    <i data-lucide="help-circle" class="w-3.5 h-3.5 text-brand-400"></i> FAQ Item Accordion
                                </button>
                                <button type="button" @click="insertSnippet('table'); openSnippets = false" class="w-full text-left px-3 py-2 hover:bg-slate-700 flex items-center gap-2">
                                    <i data-lucide="table" class="w-3.5 h-3.5 text-emerald-400"></i> Diagnostic Table
                                </button>
                                <button type="button" @click="insertSnippet('callout'); openSnippets = false" class="w-full text-left px-3 py-2 hover:bg-slate-700 flex items-center gap-2">
                                    <i data-lucide="shield" class="w-3.5 h-3.5 text-amber-400"></i> Cleanroom Callout Box
                                </button>
                                <button type="button" @click="insertSnippet('grid3'); openSnippets = false" class="w-full text-left px-3 py-2 hover:bg-slate-700 flex items-center gap-2">
                                    <i data-lucide="grid" class="w-3.5 h-3.5 text-sky-400"></i> 3-Column Card Grid
                                </button>
                            </div>
                        </div>

                        <button type="button" onclick="openMediaModal(function(item) { window.insertMediaIntoEditor(item.url, item.name); })" 
                                class="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition">
                            <i data-lucide="image" class="w-3.5 h-3.5 text-brand-400"></i>
                            <span>Add Media</span>
                        </button>
                    </div>
                </div>

                <!-- Hidden Input Bound to Form Submission -->
                <textarea name="content" id="serviceContentInput" class="hidden" x-model="content"></textarea>

                <!-- TAB 1: HTML Source Code View (Monospace, Indented, 100% Preservation) -->
                <div x-show="activeTab === 'code'" class="p-4 bg-slate-950 font-mono text-xs">
                    <div class="flex items-center justify-between text-[11px] text-slate-400 mb-2 pb-2 border-b border-slate-800">
                        <span>Raw HTML editor &bull; Edit headings, diagnostic grids, Tailwind classes, and tables directly.</span>
                        <span x-text="content.length + ' characters'"></span>
                    </div>
                    <textarea id="codeTextarea" x-model="content" @input="syncFromCode()" rows="24"
                              class="w-full bg-slate-900 text-emerald-300 p-4 rounded-xl border border-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500 font-mono text-xs leading-relaxed"></textarea>
                </div>

                <!-- TAB 2: Visual WYSIWYG Editor (ContentEditable with Rich Formatting, Zero Tag Stripping) -->
                <div x-show="activeTab === 'visual'" class="bg-white">
                    <div class="p-2.5 bg-slate-100 border-b border-slate-200 flex flex-wrap items-center gap-1.5 text-xs text-slate-700">
                        <button type="button" @click="execCommand('bold')" class="p-1.5 hover:bg-slate-200 rounded font-bold" title="Bold"><b>B</b></button>
                        <button type="button" @click="execCommand('italic')" class="p-1.5 hover:bg-slate-200 rounded italic" title="Italic"><i>I</i></button>
                        <button type="button" @click="execCommand('underline')" class="p-1.5 hover:bg-slate-200 rounded underline" title="Underline"><u>U</u></button>
                        <span class="text-slate-300">|</span>
                        <button type="button" @click="execFormat('h2')" class="px-2 py-1 hover:bg-slate-200 rounded font-bold text-xs" title="Heading 2">H2</button>
                        <button type="button" @click="execFormat('h3')" class="px-2 py-1 hover:bg-slate-200 rounded font-bold text-xs" title="Heading 3">H3</button>
                        <button type="button" @click="execFormat('h4')" class="px-2 py-1 hover:bg-slate-200 rounded font-bold text-xs" title="Heading 4">H4</button>
                        <button type="button" @click="execFormat('p')" class="px-2 py-1 hover:bg-slate-200 rounded text-xs" title="Paragraph">P</button>
                        <span class="text-slate-300">|</span>
                        <button type="button" @click="execCommand('insertUnorderedList')" class="p-1.5 hover:bg-slate-200 rounded" title="Bullet List">&bull; List</button>
                        <button type="button" @click="execCommand('insertOrderedList')" class="p-1.5 hover:bg-slate-200 rounded" title="Numbered List">1. List</button>
                        <span class="text-slate-300">|</span>
                        <button type="button" @click="execPromptLink()" class="px-2 py-1 hover:bg-slate-200 rounded text-xs" title="Insert Link">🔗 Link</button>
                        <button type="button" @click="execCommand('removeFormat')" class="px-2 py-1 hover:bg-slate-200 rounded text-xs text-slate-500" title="Clear Formatting">Clear</button>
                    </div>

                    <div id="visualEditorContainer" contenteditable="true" @input="syncFromVisual()" 
                         class="p-6 min-h-[460px] focus:outline-none prose prose-slate max-w-none text-slate-800 text-sm leading-relaxed"
                         x-html="content"></div>
                </div>

                <!-- TAB 3: Full Frontend Live Preview -->
                <div x-show="activeTab === 'preview'" class="p-8 bg-slate-50 min-h-[460px]">
                    <div class="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm max-w-4xl mx-auto">
                        <div class="mb-4 pb-3 border-b border-slate-100 flex items-center justify-between text-xs text-slate-400">
                            <span>Frontend Rendering Simulation</span>
                            <span class="font-bold text-emerald-600">Live Rendered View</span>
                        </div>
                        <div class="prose prose-slate max-w-none text-slate-800 text-sm sm:text-base leading-relaxed" x-html="content"></div>
                    </div>
                </div>
            </div>

            <!-- Short Summary Card -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-2">
                <label for="serviceSummary" class="block text-xs font-bold uppercase tracking-wider text-slate-700">Short Summary</label>
                <p class="text-xs text-slate-400">Concise 1-2 sentence description displayed on homepage and service index cards.</p>
                <textarea id="serviceSummary" name="summary" rows="3" placeholder="Brief summary of what this cleanroom service offers..."
                          class="w-full px-4 py-2.5 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-600 transition"><?php echo e(old('summary', $service->summary ?? '')); ?></textarea>
            </div>

            <!-- Features & Benefits Grids -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Features Card -->
                <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-2">
                    <label for="featuresInput" class="block text-xs font-bold uppercase tracking-wider text-slate-700">Core Technical Capabilities</label>
                    <p class="text-[11px] text-slate-400">Enter one feature per line. Rendered as technical checkmark badges.</p>
                    <textarea id="featuresInput" name="features_input" rows="6" 
                              placeholder="Fleet Capacity Range: 20 kVA to 2500 kVA (Single Units & Multi-MW Plants)&#10;Tier-1 Engine Partners: Cummins, Perkins, Caterpillar & Kohler with Stamford Alternators&#10;Sound-Attenuated Weatherproof Acoustic Canopies (65 to 72 dBA @ 7m)&#10;High-Ambient 52°C Desert Tropicalized Cooling Radiators & Sand Traps"
                              class="w-full px-3.5 py-2.5 text-xs font-mono rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-600"><?php echo e(old('features_input', $featuresString ?? '')); ?></textarea>
                </div>

                <!-- Benefits / Impact Card -->
                <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-2">
                    <label for="benefitsInput" class="block text-xs font-bold uppercase tracking-wider text-slate-700">Why Choose Generator Dubai Power Solutions</label>
                    <p class="text-[11px] text-slate-400">Enter one benefit per line. Rendered in the verified commercial advantage box.</p>
                    <textarea id="benefitsInput" name="benefits_input" rows="6" 
                              placeholder="Single-Source Accountability: Generator hire, fuel delivery, cabling & operators&#10;Zero Hidden Charges: Fully itemized, transparent quotations with predictable billing&#10;100% Load-Bank Certified: Every genset tested under full load before dispatching&#10;DEWA & ADDC Compliant: 4-pole motorized circuit breakers, spark arrestors & grounding"
                              class="w-full px-3.5 py-2.5 text-xs font-mono rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-600"><?php echo e(old('benefits_input', $benefitsString ?? '')); ?></textarea>
                </div>
            </div>

            <!-- Yoast SEO Box -->
            <?php echo $__env->make('admin.partials.yoast-seo-box', [
                'model' => $service ?? null,
                'titleInputId' => 'serviceTitle',
                'slugInputId' => 'serviceSlug',
                'contentInputId' => 'serviceContentInput',
                'urlPrefix' => url('/service'),
                'type' => 'service'
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        </div>

        <!-- Right Sidebar (1 Col) -->
        <div class="space-y-6">

            <!-- Publish Settings Card -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
                <h3 class="font-bold text-slate-900 text-sm border-b border-slate-100 pb-3 flex items-center justify-between">
                    <span>Publish Settings</span>
                    <?php if($isEdit): ?>
                        <a href="<?php echo e(route('service.show', $service->slug)); ?>" target="_blank" class="text-xs font-semibold text-brand-600 hover:underline">Preview ↗</a>
                    <?php endif; ?>
                </h3>

                <!-- Status Selector -->
                <div>
                    <label for="serviceStatus" class="block text-xs font-semibold text-slate-700 mb-1.5">Status</label>
                    <select id="serviceStatus" name="status" class="w-full text-xs rounded-xl border border-slate-200 p-2.5 focus:outline-none focus:ring-2 focus:ring-brand-500/20">
                        <option value="published" <?php echo e(old('status', $service->status ?? 'published') === 'published' ? 'selected' : ''); ?>>Published (Active on site)</option>
                        <option value="draft" <?php echo e(old('status', $service->status ?? '') === 'draft' ? 'selected' : ''); ?>>Draft (Hidden)</option>
                    </select>
                </div>

                <!-- Display Order -->
                <div>
                    <label for="serviceOrder" class="block text-xs font-semibold text-slate-700 mb-1.5">Display Order</label>
                    <input type="number" id="serviceOrder" name="order" value="<?php echo e(old('order', $service->order ?? 0)); ?>"
                           class="w-full text-xs rounded-xl border border-slate-200 p-2.5 focus:outline-none focus:ring-2 focus:ring-brand-500/20">
                    <p class="text-[11px] text-slate-400 mt-1">Lower numbers appear first on the frontend.</p>
                </div>

                <!-- Featured Toggle -->
                <div class="pt-2">
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="is_featured" value="1" <?php echo e(old('is_featured', $service->is_featured ?? true) ? 'checked' : ''); ?>

                               class="rounded border-slate-300 text-brand-600 focus:ring-brand-500 h-4 w-4">
                        <span class="text-xs font-semibold text-slate-700">Feature on Homepage</span>
                    </label>
                </div>

                <!-- Action Buttons -->
                <div class="pt-4 flex flex-col gap-2 border-t border-slate-100">
                    <button type="submit" 
                            class="w-full py-2.5 px-4 bg-brand-600 hover:bg-brand-700 text-white rounded-xl text-xs font-bold shadow-md shadow-brand-500/20 transition flex items-center justify-center gap-2">
                        <i data-lucide="check" class="w-4 h-4"></i>
                        <span><?php echo e($isEdit ? 'Update Service' : 'Save & Publish Service'); ?></span>
                    </button>
                    <?php if($isEdit): ?>
                        <button type="button" onclick="if(confirm('Are you sure you want to delete this service?')) { document.getElementById('deleteServiceForm').submit(); }" 
                                class="w-full py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-xl transition">
                            Delete Service
                        </button>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Icon Picker Card -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-3" x-data="{ selectedIcon: '<?php echo e(old('icon', $service->icon ?? 'hard-drive')); ?>' }">
                <h3 class="font-bold text-slate-900 text-xs uppercase tracking-wider border-b border-slate-100 pb-2">Lucide Icon</h3>
                <p class="text-[11px] text-slate-400">Select an icon for cards and navigation:</p>
                
                <input type="text" id="iconInput" name="icon" x-model="selectedIcon"
                       placeholder="e.g. hard-drive, database, cpu, shield-check"
                       class="w-full px-3 py-2 text-xs font-mono rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500/20">

                <div class="grid grid-cols-4 gap-2 pt-1">
                    <?php
                        $presetIcons = ['hard-drive', 'database', 'cpu', 'shield-check', 'smartphone', 'server', 'video', 'usb', 'lock', 'activity', 'sparkles', 'check-circle'];
                    ?>
                    <?php $__currentLoopData = $presetIcons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" @click="selectedIcon = '<?php echo e($ico); ?>'"
                                :class="selectedIcon === '<?php echo e($ico); ?>' ? 'border-brand-600 bg-brand-50 text-brand-700' : 'border-slate-200 hover:border-slate-300 text-slate-600'"
                                class="p-2 border rounded-xl flex items-center justify-center transition" title="<?php echo e($ico); ?>">
                            <i data-lucide="<?php echo e($ico); ?>" class="w-4 h-4"></i>
                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Featured Image / Thumbnail Card -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-3">
                <h3 class="font-bold text-slate-900 text-xs uppercase tracking-wider border-b border-slate-100 pb-2">Featured Image</h3>
                <p class="text-[11px] text-slate-400">Image URL or select from Media Library.</p>
                
                <div class="flex items-center gap-2">
                    <input type="text" id="featuredImageInput" name="featured_image" value="<?php echo e(old('featured_image', $service->featured_image ?? '')); ?>"
                           placeholder="https://... or image path"
                           class="flex-1 px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-brand-500/20">
                    <button type="button" onclick="openMediaModal(function(item) { document.getElementById('featuredImageInput').value = item.url; document.getElementById('featuredImagePreviewImg').src = item.url; document.getElementById('featuredImagePreviewWrap').classList.remove('hidden'); })"
                            class="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition shrink-0">
                        Select
                    </button>
                </div>

                <?php $featUrl = $service->featured_image_url ?? old('featured_image'); ?>
                <div id="featuredImagePreviewWrap" class="rounded-xl overflow-hidden border border-slate-200 aspect-video <?php echo e($featUrl ? '' : 'hidden'); ?>">
                    <img id="featuredImagePreviewImg" src="<?php echo e($featUrl ?: ''); ?>" alt="<?php echo e($service->title ?? 'Preview'); ?>" class="w-full h-full object-cover">
                </div>
            </div>

        </div>
    </div>
</form>

<?php if($isEdit): ?>
    <form id="deleteServiceForm" action="<?php echo e(route('admin.services.destroy', $service)); ?>" method="POST" class="hidden">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
    </form>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
<script>
function serviceContentEditor(config) {
    return {
        activeTab: 'code', // Default to Code mode so nothing gets stripped
        content: config.initial || '',
        setTab(tab) {
            if (this.activeTab === 'visual') {
                const vis = document.getElementById('visualEditorContainer');
                if (vis) {
                    this.content = vis.innerHTML;
                }
            }
            this.activeTab = tab;
            if (tab === 'visual') {
                this.$nextTick(() => {
                    const vis = document.getElementById('visualEditorContainer');
                    if (vis) {
                        vis.innerHTML = this.content;
                    }
                });
            }
        },
        syncFromCode() {
            document.getElementById('serviceContentInput').value = this.content;
        },
        syncFromVisual() {
            const vis = document.getElementById('visualEditorContainer');
            if (vis) {
                this.content = vis.innerHTML;
                document.getElementById('serviceContentInput').value = this.content;
            }
        },
        execCommand(cmd, val = null) {
            document.execCommand(cmd, false, val);
            this.syncFromVisual();
        },
        execFormat(tag) {
            document.execCommand('formatBlock', false, tag);
            this.syncFromVisual();
        },
        execPromptLink() {
            const url = prompt('Enter link URL:');
            if (url) {
                document.execCommand('createLink', false, url);
                this.syncFromVisual();
            }
        },
        insertSnippet(type) {
            let snippet = '';
            if (type === 'faq') {
                snippet = `\n<details class="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-sm group">\n    <summary class="font-bold text-slate-900 cursor-pointer flex items-center justify-between text-sm sm:text-base">\n        <span>What is the cost of diesel generator rental in Dubai and UAE?</span>\n        <span class="text-amber-600 font-bold group-open:rotate-180 transition-transform">▼</span>\n    </summary>\n    <div class="mt-3 text-xs sm:text-sm text-slate-600 leading-relaxed pt-2 border-t border-slate-100">\n        Rental rates depend on the kVA capacity, rental duration (daily, weekly, or monthly contract), fuel management requirements, and site location. Monthly rental packages offer substantial savings and include complete 250-hour scheduled oil and filter servicing, consumable top-ups, and 24/7 on-call emergency technician support.\n    </div>\n</details>\n`;
            } else if (type === 'table') {
                snippet = `\n<div class="overflow-x-auto rounded-2xl border border-slate-200 my-6 shadow-sm">\n    <table class="w-full text-left text-xs sm:text-sm">\n        <thead class="bg-slate-900 text-white font-bold uppercase text-[11px] tracking-wider">\n            <tr>\n                <th class="py-3 px-4">kVA Band</th>\n                <th class="py-3 px-4">Engine Model</th>\n                <th class="py-3 px-4">Fuel Burn (75% Load)</th>\n                <th class="py-3 px-4">Sound Level (@ 7m)</th>\n            </tr>\n        </thead>\n        <tbody class="divide-y divide-slate-100">\n            <tr class="hover:bg-slate-50">\n                <td class="py-3 px-4 font-bold text-slate-900">50 kVA (40 kW)</td>\n                <td class="py-3 px-4 text-slate-600">Perkins 1103A / Cummins X2.5</td>\n                <td class="py-3 px-4 text-slate-600">~11.5 L/hr</td>\n                <td class="py-3 px-4 font-semibold text-emerald-600">68 dBA (Silent Canopy)</td>\n            </tr>\n            <tr class="hover:bg-slate-50">\n                <td class="py-3 px-4 font-bold text-slate-900">500 kVA (400 kW)</td>\n                <td class="py-3 px-4 text-slate-600">Cummins QSX15 / Perkins 2506</td>\n                <td class="py-3 px-4 text-slate-600">~105 L/hr</td>\n                <td class="py-3 px-4 font-semibold text-emerald-600">72 dBA (Containerized)</td>\n            </tr>\n        </tbody>\n    </table>\n</div>\n`;
            } else if (type === 'callout') {
                snippet = `\n<div class="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800 to-amber-950 text-white border border-amber-500/30 my-6 space-y-2">\n    <div class="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider">\n        <span>ISO 8528-1:2018 Certified Tropicalized Power Fleet</span>\n    </div>\n    <h4 class="text-lg font-black text-white">52°C Extreme Desert Ambient Reliability Guarantee</h4>\n    <p class="text-xs sm:text-sm text-slate-300 leading-relaxed">\n        Every diesel generator deployed across UAE sites is fitted with high-ambient tropical radiators, dual air-filtration sand traps, and DEWA/ADDC compliant grounding systems to ensure zero thermal tripping.\n    </p>\n</div>\n`;
            } else if (type === 'grid3') {
                snippet = `\n<div class="grid grid-cols-1 md:grid-cols-3 gap-4 my-6">\n    <div class="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">\n        <h4 class="font-bold text-slate-900 text-sm">Step 1: Free Power Sizing</h4>\n        <p class="text-xs text-slate-600 leading-relaxed">Technical load study and inrush current calculation to match the exact kVA without excess cost.</p>\n    </div>\n    <div class="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">\n        <h4 class="font-bold text-slate-900 text-sm">Step 2: Rapid 2-Hour Dispatch</h4>\n        <p class="text-xs text-slate-600 leading-relaxed">Crane offloading, placement, and heavy-duty H07RN-F cabling to your site distribution boards.</p>\n    </div>\n    <div class="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">\n        <h4 class="font-bold text-slate-900 text-sm">Step 3: 24/7 Fuel & Maintenance</h4>\n        <p class="text-xs text-slate-600 leading-relaxed">Continuous fuel telemetry top-ups, scheduled 250-hour oil services, and 99.98% uptime SLA.</p>\n    </div>\n</div>\n`;
            }
            this.content += snippet;
            document.getElementById('serviceContentInput').value = this.content;
            if (this.activeTab === 'visual') {
                const vis = document.getElementById('visualEditorContainer');
                if (vis) vis.innerHTML = this.content;
            }
        }
    };
}

// Global media helper
window.insertMediaIntoEditor = function(url, name) {
    const imgHtml = `\n<img src="${url}" alt="${name || 'Generator Dubai'}" class="rounded-2xl max-w-full h-auto my-4 shadow-sm" />\n`;
    const textarea = document.getElementById('codeTextarea');
    const vis = document.getElementById('visualEditorContainer');
    const hiddenInput = document.getElementById('serviceContentInput');

    if (textarea) {
        textarea.value += imgHtml;
        textarea.dispatchEvent(new Event('input', { bubbles: true }));
    }
    if (vis) {
        vis.innerHTML += imgHtml;
        vis.dispatchEvent(new Event('input', { bubbles: true }));
    }
    if (hiddenInput) {
        hiddenInput.value += imgHtml;
        hiddenInput.dispatchEvent(new Event('input', { bubbles: true }));
    }
};

document.addEventListener('DOMContentLoaded', function () {
    const titleInput = document.getElementById('serviceTitle');
    const slugInput = document.getElementById('serviceSlug');
    const slugDisplay = document.getElementById('slugDisplay');

    // Auto-generate slug from title if new
    <?php if(! $isEdit): ?>
    if (titleInput && slugInput && slugDisplay) {
        titleInput.addEventListener('input', function() {
            const raw = titleInput.value.toLowerCase()
                .replace(/[^\w\s-]/g, '')
                .replace(/[\s_-]+/g, '-')
                .replace(/^-+|-+$/g, '');
            slugInput.value = raw;
            slugDisplay.textContent = raw || 'your-service-slug';
        });
    }
    <?php endif; ?>
});
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\CMS\saudia_site\resources\views/admin/services/form.blade.php ENDPATH**/ ?>