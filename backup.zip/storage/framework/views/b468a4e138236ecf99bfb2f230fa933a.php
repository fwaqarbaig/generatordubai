<?php $__env->startSection('seo_meta'); ?>
    <!-- Primary Meta Tags -->
    <title><?php echo e($page->seo_title); ?> - <?php echo e(config('app.name', 'Generator Dubai')); ?></title>
    <meta name="title" content="<?php echo e($page->seo_title); ?> - <?php echo e(config('app.name', 'Generator Dubai')); ?>">
    <meta name="description" content="<?php echo e($page->seo_description); ?>">
    <?php if($page->meta_keywords): ?>
        <meta name="keywords" content="<?php echo e($page->meta_keywords); ?>">
    <?php endif; ?>
    <link rel="canonical" href="<?php echo e($page->canonical_url ?: url()->current()); ?>">
    <meta name="robots" content="<?php echo e($page->is_indexable ? 'index, follow' : 'noindex, nofollow'); ?>">

    <!-- Open Graph -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta property="og:title" content="<?php echo e($page->og_title ?: $page->seo_title); ?>">
    <meta property="og:description" content="<?php echo e($page->og_description ?: $page->seo_description); ?>">
    <?php if($page->seo_image): ?>
        <meta property="og:image" content="<?php echo e($page->seo_image); ?>">
    <?php endif; ?>
    <meta property="og:site_name" content="<?php echo e(config('app.name', 'Generator Dubai')); ?>">

    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo e($page->og_title ?: $page->seo_title); ?>">
    <meta name="twitter:description" content="<?php echo e($page->og_description ?: $page->seo_description); ?>">
    <?php if($page->seo_image): ?>
        <meta name="twitter:image" content="<?php echo e($page->seo_image); ?>">
    <?php endif; ?>

    <!-- Custom Schema.org JSON-LD (from Dashboard) -->
    <?php if (isset($component)) { $__componentOriginal97aaa7ec6ba4597a3ca98c8c57a79ecd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal97aaa7ec6ba4597a3ca98c8c57a79ecd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.schema-json-ld','data' => ['schema' => $page->schema_markup]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('schema-json-ld'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['schema' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($page->schema_markup)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal97aaa7ec6ba4597a3ca98c8c57a79ecd)): ?>
<?php $attributes = $__attributesOriginal97aaa7ec6ba4597a3ca98c8c57a79ecd; ?>
<?php unset($__attributesOriginal97aaa7ec6ba4597a3ca98c8c57a79ecd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal97aaa7ec6ba4597a3ca98c8c57a79ecd)): ?>
<?php $component = $__componentOriginal97aaa7ec6ba4597a3ca98c8c57a79ecd; ?>
<?php unset($__componentOriginal97aaa7ec6ba4597a3ca98c8c57a79ecd); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="py-12 bg-white">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <!-- Page Header -->
        <header class="space-y-4 border-b border-slate-100 pb-8">
            <h1 class="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-tight">
                <?php echo e($page->title); ?>

            </h1>
            <?php if($page->updated_at): ?>
                <div class="text-xs text-slate-400">
                    Last updated on <?php echo e($page->updated_at->format('F d, Y')); ?>

                </div>
            <?php endif; ?>
        </header>

        <!-- Featured Image -->
        <?php if($page->featured_image_url): ?>
            <div class="rounded-3xl overflow-hidden aspect-[21/9] shadow-md bg-slate-100">
                <img src="<?php echo e($page->featured_image_url); ?>" 
                     alt="<?php echo e($page->title); ?>" 
                     width="1200" 
                     height="514" 
                     loading="eager" 
                     fetchpriority="high" 
                     class="w-full h-full object-cover">
            </div>

        <?php endif; ?>

        <!-- Page WYSIWYG Content Body -->
        <div class="prose prose-slate prose-lg max-w-none leading-relaxed">
            <?php echo $page->content; ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\CMS\saudia_site\resources\views/frontend/pages/show.blade.php ENDPATH**/ ?>