<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['schema' => null, 'data' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['schema' => null, 'data' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $payload = $data ?? $schema;
?>

<?php if(!empty($payload)): ?>
    <?php if(is_array($payload)): ?>
        <script type="application/ld+json">
        <?php echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE); ?>

        </script>
    <?php else: ?>
        <?php
            $trimmed = trim((string) $payload);
        ?>
        <?php if(str_starts_with($trimmed, '<script')): ?>
            <?php echo $trimmed; ?>

        <?php else: ?>
            <script type="application/ld+json">
            <?php echo $trimmed; ?>

            </script>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH D:\CMS\saudia_site\resources\views/components/schema-json-ld.blade.php ENDPATH**/ ?>